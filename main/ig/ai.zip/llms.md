# ans.fhir.fr.mesmesures#0.1.0: ANS IG Example

## Pages

* [Accueil](index.md)
* [Spécifications techniques](specifications-techniques.md)
* [Artifacts Summary](artifacts.md)
* [Téléchargements et usages](downloads.md)
* [Autres Ressources](autres_ressources.md)
* [Historique des versions](change-log.md)
* [Sécurité](securite.md)

## Resources

### Resource Profiles

* [MESObservationBmi](StructureDefinition-MESObservationBmi.md)
* [MESObservationBodyHeight](StructureDefinition-MESObservationBodyHeight.md)
* [MESObservationBodyTemperature](StructureDefinition-MESObservationBodyTemperature.md)
* [MESObservationBodyWeight](StructureDefinition-MESObservationBodyWeight.md)
* [MESObservationBp](StructureDefinition-MESObservationBp.md)
* [MESObservationGlucose](StructureDefinition-MESObservationGlucose.md)
* [MESObservationHeadCircumference](StructureDefinition-MESObservationHeadCircumference.md)
* [MESObservationHeartrate](StructureDefinition-MESObservationHeartrate.md)
* [MESObservationPainSeverity](StructureDefinition-MESObservationPainSeverity.md)
* [MESObservationStepsByDay](StructureDefinition-MESObservationStepsByDay.md)
* [MESObservationWaistCircumference](StructureDefinition-MESObservationWaistCircumference.md)

### ImplementationGuides

* [ANS IG Example](index.md)
