# Historique des versions - ANS IG Example v0.1.0

* [**Table of Contents**](toc.md)
* **Historique des versions**

## Historique des versions

### Historique des versions

#### Version 1.5.2 - 21/07/2023

Modification du subject.identifier (ajout de l'Assign.Auth récupéré lors de l'appariement)

#### Version 1.5.1 - 10/05/2023

Changement du paramètre de recherche via l'idpe de l'usager, de « patient » à « subject.identifier »

#### Version 1.5 - 13/04/2022

Ajout des urls canoniques finales et de la dépendance à l'Implementation Guide de l'ANS

#### Version 1.4 - 18/01/2022

Mise à jour suite à la relecture de l'ANS + Device rendu optionnel dans le flux d'alimentation

#### Version 1.3 - 22/08/2022

Ajout de la pagination au flux de recherche

#### Version 1.2 - 28/07/2022

Modifications de forme et harmonisation avec les autres spécifications Mon espace santé

#### Version 1.1 - 15/12/2021

Ajout du flux de recherche

#### Version 1 - 30/11/2021

Séparation des spécifications des API Mesures et Appariement dans deux documents séparés pour simplification de la lecture par les éditeurs.

