# Accueil - ANS IG Example v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/mesmesures/ImplementationGuide/ans.fhir.fr.mesmesures | *Version*:0.1.0 |
| Draft as of 2026-02-26 | *Computable Name*:ExampleIG |

> Guide d'implémentation de démo, celui-ci n'a pas vocation à être utilisé

 **Guide d'Implémentation FHIR - API Mesures de santé de Mon Espace Santé**
 Ce guide d'implémentation définit les spécifications FHIR pour l'interopérabilité avec l'API Mesures de santé de Mon Espace Santé, permettant aux systèmes partenaires de consulter et d'alimenter les mesures de santé des utilisateurs. 

> Cet Implementation Guide n'est pas la version courante, il s'agit de la version en intégration continue soumise à des changements fréquents uniquement destinée à suivre les travaux en cours. La version courante sera accessible via l'URL canonique suite à la première release : https://interop.esante.gouv.fr/ig/fhir/mesmesures

Ce guide d'implémentation est un test pour mettre MonEspaceSanté au format IG, et également un test pour mettre plusieurs versions du même package en dépendance.

### Introduction

La documentation technique de Mon espace santé s'applique aux services ayant ou visant à avoir des échanges de données avec MES (Mon Espace Santé).

Ce guide d'implémentation présente les spécifications FHIR de l'**API Mesures de santé** qui permet aux systèmes partenaires interfacés avec Mon Espace Santé de :

* Consulter les mesures d'un utilisateur
* Alimenter des mesures prises via des services tiers
* Proposer à l'utilisateur une vue à jour de ses mesures de santé

Les principales sections de l'IG sont :

* **Spécifications techniques** : Description détaillée des flux d'alimentation et de recherche
* **Ressources de conformité** : Profils FHIR des mesures de santé (Observation, Device)
* **Historique des versions** : Suivi des évolutions de l'API

### Périmètre du projet

L'API Mesures de santé permet l'échange de **11 types de mesures de santé** entre les systèmes partenaires et Mon Espace Santé :

* Poids corporel (Body Weight)
* Taille (Body Height)
* Indice de Masse Corporelle - IMC (Body Mass Index)
* Pression artérielle (Blood Pressure)
* Température corporelle (Body Temperature)
* Glycémie (Glucose)
* Niveau de douleur (Pain Severity)
* Nombre de pas quotidien (Steps By Day)
* Tour de taille (Waist Circumference)
* Tour de tête (Head Circumference)
* Fréquence cardiaque (Heart Rate)

Les flux couverts sont :

* **Flux d'alimentation** : Envoi de mesures vers Mon Espace Santé via un Bundle FHIR de type transaction
* **Flux de recherche** : Consultation des mesures stockées dans Mon Espace Santé

Toutes les requêtes doivent répondre aux exigences d'authentification et d'identification décrites dans la spécification d'appariement.

### Interactions préliminaires

Les interactions entre les partenaires et Mon Espace Santé s'organisent en trois phases préliminaires aux échanges :

1. **Phase administrative**: Référencement et contractualisation
1. **Phase de setup technique**: Connectivité, partage de secrets, certificats
1. **Appariement initial**: Consentement de l'utilisateur à l'échange de données avec le partenaire

### Documents référencés

| | |
| :--- | :--- |
| Volet mesures de santé v1.2 | Spécifications techniques d'alimentation et de consultation des mesures de santé |
| Spécifications d'interopérabilité au format Guide d'implémentation v3.0 | Spécifications techniques publiées sous forme d'Implementation Guide |

Le Document chapeau des APIs Mon espace santé peut être trouvé sur le portail de référencement à l'adresse [Référencement éditeurs (monespacesante.fr)](https://monespacesante.fr).

### Dépendances








### Propriété intellectuelle

Certaines ressources sémantiques de ce guide sont protégées par des droits de propriété intellectuelle couverte par les déclarations ci-dessous. L’utilisation de ces ressources est soumise à l’acceptation et au respect des conditions précisées dans la licence d’utilisation de chacune d’entre elle.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.0.2/CodeSystem-ISO3166Part1.html): [ExampleIG](index.md), [MESObservationBmi](StructureDefinition-MESObservationBmi.md)... Show 10 more, [MESObservationBodyHeight](StructureDefinition-MESObservationBodyHeight.md), [MESObservationBodyTemperature](StructureDefinition-MESObservationBodyTemperature.md), [MESObservationBodyWeight](StructureDefinition-MESObservationBodyWeight.md), [MESObservationBp](StructureDefinition-MESObservationBp.md), [MESObservationGlucose](StructureDefinition-MESObservationGlucose.md), [MESObservationHeadCircumference](StructureDefinition-MESObservationHeadCircumference.md), [MESObservationHeartrate](StructureDefinition-MESObservationHeartrate.md), [MESObservationPainSeverity](StructureDefinition-MESObservationPainSeverity.md), [MESObservationStepsByDay](StructureDefinition-MESObservationStepsByDay.md) and [MESObservationWaistCircumference](StructureDefinition-MESObservationWaistCircumference.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.0.2/CodeSystem-v3-ucum.html): [MESObservationBodyHeight](StructureDefinition-MESObservationBodyHeight.md), [MESObservationBodyTemperature](StructureDefinition-MESObservationBodyTemperature.md)... Show 4 more, [MESObservationBodyWeight](StructureDefinition-MESObservationBodyWeight.md), [MESObservationHeadCircumference](StructureDefinition-MESObservationHeadCircumference.md), [MESObservationStepsByDay](StructureDefinition-MESObservationStepsByDay.md) and [MESObservationWaistCircumference](StructureDefinition-MESObservationWaistCircumference.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.0.2/CodeSystem-v3-loinc.html): [MESObservationHeadCircumference](StructureDefinition-MESObservationHeadCircumference.md), [MESObservationPainSeverity](StructureDefinition-MESObservationPainSeverity.md), [MESObservationStepsByDay](StructureDefinition-MESObservationStepsByDay.md) and [MESObservationWaistCircumference](StructureDefinition-MESObservationWaistCircumference.md)


