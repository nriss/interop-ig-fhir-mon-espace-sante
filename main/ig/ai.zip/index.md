# Accueil - ANS IG Example v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/mesmesures/ImplementationGuide/ans.fhir.fr.mesmesures | *Version*:0.1.0 |
| Draft as of 2026-01-20 | *Computable Name*:ExampleIG |

 **Brief description of this Implementation Guide**
 [Add a brief description of this IG in English] 

> Cet Implementation Guide n'est pas la version courante, il s'agit de la version en intégration continue soumise à des changements fréquents uniquement destinée à suivre les travaux en cours. La version courante sera accessible via l'URL canonique suite à la première release : http://interop.esante.gouv.fr/ig/fhir/[code - ig]

### Introduction

Définir ici de quoi parle l'IG (En termes non expert, compréhensible par un patient). Rajouter également les détails techniques sur le contexte et le besoin de cet IG

Les principales sections de l'IG sont :

* Le contexte de l'IG, quelle problématique il résout
* Ce que les Implémenteurs doivent mettre en place
* Un onglet "Ressources de conformité" pour s'assurer d'un schéma global entre tous les IGs

### Périmètre du projet

Définir en quelques lignes quel est le périmètre du projet

Toujours laisser l'onglet "Ressources de conformité" pour s'assurer d'une cohérence globales entre tous les IGs

### Auteurs et contributeurs (optionnel)

| | | | |
| :--- | :--- | :--- | :--- |
| **Primary Editor** | Prenom Nom | Agence du Numérique en Santé | prenom.nom@address.email |

### Dépendances








### Propriété intellectuelle

Certaines ressources sémantiques de ce guide sont protégées par des droits de propriété intellectuelle couverte par les déclarations ci-dessous. L’utilisation de ces ressources est soumise à l’acceptation et au respect des conditions précisées dans la licence d’utilisation de chacune d’entre elle.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.0.2/CodeSystem-ISO3166Part1.html): [ExampleIG](index.md), [MESObservationBmi](StructureDefinition-MESObservationBmi.md)...Show 10 more,[MESObservationBodyHeight](StructureDefinition-MESObservationBodyHeight.md),[MESObservationBodyTemperature](StructureDefinition-MESObservationBodyTemperature.md),[MESObservationBodyWeight](StructureDefinition-MESObservationBodyWeight.md),[MESObservationBp](StructureDefinition-MESObservationBp.md),[MESObservationGlucose](StructureDefinition-MESObservationGlucose.md),[MESObservationHeadCircumference](StructureDefinition-MESObservationHeadCircumference.md),[MESObservationHeartrate](StructureDefinition-MESObservationHeartrate.md),[MESObservationPainSeverity](StructureDefinition-MESObservationPainSeverity.md),[MESObservationStepsByDay](StructureDefinition-MESObservationStepsByDay.md)and[MESObservationWaistCircumference](StructureDefinition-MESObservationWaistCircumference.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.0.2/CodeSystem-v3-ucum.html): [MESObservationBodyHeight](StructureDefinition-MESObservationBodyHeight.md), [MESObservationBodyTemperature](StructureDefinition-MESObservationBodyTemperature.md)...Show 4 more,[MESObservationBodyWeight](StructureDefinition-MESObservationBodyWeight.md),[MESObservationHeadCircumference](StructureDefinition-MESObservationHeadCircumference.md),[MESObservationStepsByDay](StructureDefinition-MESObservationStepsByDay.md)and[MESObservationWaistCircumference](StructureDefinition-MESObservationWaistCircumference.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.0.2/CodeSystem-v3-loinc.html): [MESObservationHeadCircumference](StructureDefinition-MESObservationHeadCircumference.md), [MESObservationPainSeverity](StructureDefinition-MESObservationPainSeverity.md), [MESObservationStepsByDay](StructureDefinition-MESObservationStepsByDay.md) and [MESObservationWaistCircumference](StructureDefinition-MESObservationWaistCircumference.md)


